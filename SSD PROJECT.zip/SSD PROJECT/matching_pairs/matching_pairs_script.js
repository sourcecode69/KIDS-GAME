const moves = document.getElementById("moves-count");
const timeValue = document.getElementById("time");
const startButton = document.getElementById("start");
const stopButton = document.getElementById("stop");
const gameContainer = document.querySelector(".game-container");
const result = document.getElementById("result");
const controls = document.querySelector(".controls-container");
let cards;
let interval;
let firstCard = false;
let secondCard = false;

// Call this function to show the modal alert
function showModalAlert() {
  const modal = document.getElementById("custom-alert");
  const modalContent = document.getElementById("modal-content");
  const music = document.getElementById("backgroundMusic");
  if (!music.paused) {
    music.pause();
  }

  // Play the "winner.mp3" song
  const winnerSound = document.getElementById("winner");
  winnerSound.play();

  // Display the modal
  modal.style.display = "block";

  // Display the game stats in the modal content
  modalContent.innerHTML = `Time: ${minutes}:${seconds}<br>Moves: ${movesCount}`;

  // Close the modal when clicking the close (X) button
  const closeBtn = document.querySelector(".close");
  closeBtn.onclick = function () {
    modal.style.display = "none";
    winnerSound.pause();
    music.play();
  };

  // Close the modal when clicking anywhere outside the modal content
  window.onclick = function (event) {
    if (event.target === modal) {
      modal.style.display = "none";
      winnerSound.pause();
      music.play();
    }
  };
}

// Define levels with corresponding card counts
const levels = {
  easy: { cardCount: 12 },
  medium: { cardCount: 20 },
  hard: { cardCount: 28 },
};

// Items array
const items = [
  { name: "koala", image: "../img/matching_pairs/koala.png" },
  { name: "lion", image: "../img/matching_pairs/lion.png" },
  { name: "fox", image: "../img/matching_pairs/fox.png" },
  { name: "cat", image: "../img/matching_pairs/cat.png" },
  { name: "rab", image: "../img/matching_pairs/rab.png" },
  { name: "hen", image: "../img/matching_pairs/hen.png" },
  { name: "dol", image: "../img/matching_pairs/dol.png" },
  { name: "crab", image: "../img/matching_pairs/crab.png" },
  { name: "ele", image: "../img/matching_pairs/ele.png" },
  { name: "dog", image: "../img/matching_pairs/dog.png" },
  { name: "panda", image: "../img/matching_pairs/panda.png" },
  { name: "horse", image: "../img/matching_pairs/horse.png" },
  { name: "tiger", image: "../img/matching_pairs/tiger.png" },
  { name: "pen", image: "../img/matching_pairs/pen.png" }
];

// Initial Time
let seconds = 0,
  minutes = 0;
// Initial moves and win count
let movesCount = 0,
  winCount = 0;

// For timer
const timeGenerator = () => {
  seconds += 1;
  // Minutes logic
  if (seconds >= 60) {
    minutes += 1;
    seconds = 0;
  }
  // Format time before displaying
  let secondsValue = seconds < 10 ? `0${seconds}` : seconds;
  let minutesValue = minutes < 10 ? `0${minutes}` : minutes;
  timeValue.innerHTML = `<span>Time:</span>${minutesValue}:${secondsValue}`;
};

// For calculating moves
const movesCounter = () => {
  movesCount += 1;
  moves.innerHTML = `<span>Moves:</span>${movesCount}`;
};

// Pick random objects from the items array
const generateRandom = (cardCount) => {
  // Temporary array
  let tempArray = [...items];
  // Initializes cardValues array
  let cardValues = [];
  // Random object selection
  for (let i = 0; i < cardCount / 2; i++) {
    const randomIndex = Math.floor(Math.random() * tempArray.length);
    cardValues.push(tempArray[randomIndex]);
    // Push two identical cards
    cardValues.push(tempArray[randomIndex]);
    // Once selected, remove the object from temp array
    tempArray.splice(randomIndex, 1);
  }
  // Shuffle the card values
  cardValues.sort(() => Math.random() - 0.5);
  return cardValues;
};

function stopGame() {
  controls.classList.remove("hide");
  stopButton.classList.add("hide");
  startButton.classList.remove("hide");
  clearInterval(interval);

  // Reset all matched cards to their default state
  cards.forEach(card => {
    if (card.classList.contains("matched")) {
      card.classList.remove("matched");
      card.classList.remove("flipped");
    }
  });

  // Reset game state variables
  movesCount = 0;
  seconds = 0;
  minutes = 0;
  winCount = 0;
  firstCard = false;
  secondCard = false;
  result.innerText = "";

  // Reset moves and time display
  moves.innerHTML = `<span>Moves:</span> ${movesCount}`;
  timeValue.innerHTML = "<span>Time:</span>00:00";
}

const matrixGenerator = (cardValues) => {
  gameContainer.innerHTML = "";
  const cols = 4; // Fixed number of columns
  const rows = Math.ceil(cardValues.length / cols); // Calculate the number of rows
  const successSound = document.getElementById('successSound');

  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      const index = i * cols + j;
      if (index < cardValues.length) {
        // Create Cards
        gameContainer.innerHTML += `
          <div class="card-container" data-card-value="${cardValues[index].name}">
            <div class="card-before">?</div>
            <div class="card-after">
              <img src="${cardValues[index].image}" class="image"/>
            </div>
          </div>
        `;
      }
    }
  }

  // Grid
  gameContainer.style.gridTemplateColumns = `repeat(${cols}, auto)`;
  gameContainer.style.gridTemplateRows = `repeat(${rows}, auto)`;

  // Cards
  cards = document.querySelectorAll(".card-container");
  cards.forEach((card) => {
    card.addEventListener("click", () => {
      //If selected card is not matched yet then only run (i.e already matched card when clicked would be ignored)
      if (!card.classList.contains("matched")) {
        //flip the cliked card
        card.classList.add("flipped");
        //if it is the firstcard (!firstCard since firstCard is initially false)
        if (!firstCard) {
          //so current card will become firstCard
          firstCard = card;
          //current cards value becomes firstCardValue
          firstCardValue = card.getAttribute("data-card-value");
        } else {
          //increment moves since user selected second card
          movesCounter();
          //secondCard and value
          secondCard = card;
          let secondCardValue = card.getAttribute("data-card-value");
          if (firstCardValue == secondCardValue) {
            successSound.currentTime = 0;
            successSound.play();
            //if both cards match add matched class so these cards would beignored next time
            firstCard.classList.add("matched");
            secondCard.classList.add("matched");

            //set firstCard to false since next card would be first now
            firstCard = false;
            //winCount increment as user found a correct match
            winCount += 1;
            //check if winCount ==half of cardValues
            // Check for win condition
            console.log("Succesfuky completed");
            // Inside your win condition check:
            if (winCount === Math.floor(cardValues.length / 2)) {
              showModalAlert();
              stopGame();
            }
          } else {
            //if the cards dont match
            //flip the cards back to normal
            let [tempFirst, tempSecond] = [firstCard, secondCard];
            firstCard = false;
            secondCard = false;
            let delay = setTimeout(() => {
              tempFirst.classList.remove("flipped");
              tempSecond.classList.remove("flipped");
            }, 900);
          }
        }
      }
    });
  });
};

// Initialize game with the selected level
function initializeGame(level) {
  // Reset the game state
  movesCount = 0;
  seconds = 0;
  minutes = 0;
  winCount = 0;
  firstCard = false;
  secondCard = false;

  // Hide the result message
  result.innerText = "";

  // Generate card values based on the selected level
  const { cardCount } = levels[level];
  const cardValues = generateRandom(cardCount);

  // Generate the game matrix with a fixed number of columns (4) and calculated rows
  matrixGenerator(cardValues);
}

// Event listeners for level buttons
document.getElementById("easy").addEventListener("click", () => {
  initializeGame("easy");
});

document.getElementById("medium").addEventListener("click", () => {
  initializeGame("medium");
});

document.getElementById("hard").addEventListener("click", () => {
  initializeGame("hard");
});

// Start the game initially with the default level (easy)
initializeGame("easy");

// Start game
startButton.addEventListener("click", () => {
  movesCount = 0;
  seconds = 0;
  minutes = 0;
  // Controls and buttons visibility
  controls.classList.add("hide");
  stopButton.classList.remove("hide");
  startButton.classList.add("hide");
  // Start timer
  interval = setInterval(timeGenerator, 1000);
  // Initial moves
  moves.innerHTML = `<span>Moves:</span> ${movesCount}`;
  // Initializer(); // You may remove this line if not needed
});

// Stop game
stopButton.addEventListener("click", () => {
  controls.classList.remove("hide");
  stopButton.classList.add("hide");
  startButton.classList.remove("hide");
  clearInterval(interval);

  // Reset all matched cards to their default state
  cards.forEach(card => {
    if (card.classList.contains("matched")) {
      card.classList.remove("matched");
      card.classList.remove("flipped");
    }
  });

  // Reset game state variables
  movesCount = 0;
  seconds = 0;
  minutes = 0;
  winCount = 0;
  firstCard = false;
  secondCard = false;
  result.innerText = "";

  // Reset moves and time display
  moves.innerHTML = `<span>Moves:</span> ${movesCount}`;
  timeValue.innerHTML = "<span>Time:</span>00:00";
});

document.addEventListener('DOMContentLoaded', function () {
  const startButton = document.getElementById('start');
  const stopButton = document.getElementById('stop');
  const easyButton = document.getElementById('easy');
  const mediumButton = document.getElementById('medium');
  const hardButton = document.getElementById('hard');
  const clickSound = document.getElementById('clickSound');
  const flipSound = document.getElementById('flipSound');
  const backButton = document.getElementById("back");

  cards.forEach((card) => {
    card.addEventListener('click', () => {
      if (!card.classList.contains('matched')) {
        // Play flip sound when a card is clicked
        flipSound.currentTime = 0;
        flipSound.play();
      }
    });
  });

  function playClickSound() {
    clickSound.currentTime = 0; // Rewind the sound to the beginning (in case it's already playing)
    clickSound.play();
  }
  backButton.addEventListener("click", function () {
    playClickSound();
    setTimeout(function () {
      window.location.href = "http://127.0.0.1:5500/main.html";
    }, 400);
  });

  startButton.addEventListener('click', function () {
    playClickSound();
    // Additional code for starting the game
  });

  stopButton.addEventListener('click', function () {
    playClickSound();
    // Additional code for stopping the game
  });

  easyButton.addEventListener('click', function () {
    playClickSound();
    // Additional code for stopping the game
  });

  mediumButton.addEventListener('click', function () {
    playClickSound();
    // Additional code for stopping the game
  });

  hardButton.addEventListener('click', function () {
    playClickSound();
    // Additional code for stopping the game
  });
});
