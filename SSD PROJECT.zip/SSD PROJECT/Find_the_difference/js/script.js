var LeftSide = document.getElementById('left');
var RightSide = document.getElementById('right');
var CubeStart = 5;
var level = 1;
var maxLevel = 10;

function GeneratePosition(max, min) {
    return Math.random() * (max - min) + min;
}

function showModalAlert(message) {
    const modal = document.getElementById("custom-alert");
    const modalContent = document.getElementById("modal-content");

    // Display the modal
    modal.style.display = "block";

    // Display the provided message in the modal content
    modalContent.innerHTML = message;

    // Close the modal when clicking the close (X) button
    const closeBtn = document.querySelector(".close");
    closeBtn.onclick = function () {
        modal.style.display = "none";
    };

    // Close the modal when clicking anywhere outside the modal content
    window.onclick = function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    };
}

function GenerateCube(CubeNum) {
    clearFaces();
    var max = LeftSide.offsetWidth - 55;
    for (var i = 0; i < CubeNum; i++) {
        var el = document.createElement('div');
        el.setAttribute("class", "cube");
        el.style.left = GeneratePosition(max, 0) + "px";
        el.style.top = GeneratePosition(max, 0) + "px";
        el.style.backgroundColor = generateRandomColor();
        LeftSide.appendChild(el);
    }
    CopyToRightSide();
}

function generateRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

function clearFaces() {
    while (LeftSide.firstChild) {
        LeftSide.removeChild(LeftSide.firstChild);
    }
    while (RightSide.firstChild) {
        RightSide.removeChild(RightSide.firstChild);
    }
}

function CopyToRightSide() {
    var LeftSideCubes = LeftSide.cloneNode(true);
    LeftSideCubes.removeChild(LeftSideCubes.lastChild);
    LeftSideCubes.removeAttribute("id");
    RightSide.appendChild(LeftSideCubes);
    MakeActions();
    LeftSideCubes = "";
}

function MakeActions() {
    var LastSquare = document.getElementById('left').lastChild;
    var status = document.getElementById('status');
    var rightColor = document.getElementById('right').lastChild.style.backgroundColor;
    LastSquare.onclick = function nextLevel(event) {
        event.stopPropagation();
        if (LastSquare.style.backgroundColor !== rightColor) {
            CubeStart = CubeStart + 5;
            level += 1;
            status.innerHTML = "Level " + level;
            if (level <= maxLevel) {
                GenerateCube(CubeStart);
            } else {
                var playAgain = confirm("Congratulations! You've completed all levels! Choose an option:");
                if (playAgain) {
                    CubeStart = 5;
                    level = 1;
                    clearFaces();
                    GenerateCubes();
                } else {
                    var backToMainMenu = confirm("Do you want to go back to the Main Menu?");
                    if (backToMainMenu) {
                        window.location.href = "http://127.0.0.1:5500/main.html";
                    }
                }
            }
        } else {
            // showModalAlert(`Wrong color! Game Over. Your level is: ${level}`);
            alert("Wrong color! Game Over. Your level is: " + level);
            CubeStart = 5;
            level = 1;
            clearFaces();
            GenerateCubes();
        }
    };
}


document.body.onclick = function bodyClick() {
    // showModalAlert(`Game Over! Your level is: ${level}`);
    alert("Game Over! Your level is: " + level);
    CubeStart = 5;
    level = 1;
    clearFaces();

    if (confirm("Do you want to start over?")) {
        window.location = "index.html";
    }
}

// Add event listeners for modal and body click just once
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById("custom-alert");
    const closeBtn = document.querySelector(".close");

    closeBtn.addEventListener('click', function() {
        modal.style.display = "none";
    });

    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });

    document.body.addEventListener('click', function() {
        // showModalAlert(`Game Over! Your level is: ${level}`);
        CubeStart = 5;
        level = 1;
        clearFaces();

        if (confirm("Do you want to start over?")) {
            window.location = "index.html";
        }
    });
});

function GenerateCubes() {
    GenerateCube(CubeStart);
}

window.onload = function () {
    GenerateCubes();
}
